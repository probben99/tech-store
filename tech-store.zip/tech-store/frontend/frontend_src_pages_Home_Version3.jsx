import React from 'react'
import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <section className="home">
      <div className="hero">
        <h2>Welcome to Tech Store</h2>
        <p>Your destination for the best laptops, smartphones, and more!</p>
        <Link className="btn" to="/products">
          Shop Now
        </Link>
      </div>
      <div className="info">
        <h3>Why Shop With Us?</h3>
        <ul>
          <li>Latest tech products</li>
          <li>Friendly support</li>
          <li>Fast local delivery</li>
        </ul>
      </div>
    </section>
  )
}