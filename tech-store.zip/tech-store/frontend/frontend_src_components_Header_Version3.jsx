import React from 'react'
import { Link } from 'react-router-dom'

export default function Header() {
  return (
    <header className="header">
      <div className="container">
        <h1>
          <Link to="/" className="logo">
            Tech Store
          </Link>
        </h1>
        <nav>
          <Link to="/products">Products</Link>
          <Link to="/cart">Cart</Link>
        </nav>
      </div>
    </header>
  )
}