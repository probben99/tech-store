import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'

export default function ProductDetail() {
  const { id } = useParams()
  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    fetch(`/api/products/${id}`)
      .then(res => {
        if (!res.ok) throw new Error('Not found')
        return res.json()
      })
      .then(data => {
        setProduct(data)
        setLoading(false)
      })
      .catch(() => {
        setLoading(false)
      })
  }, [id])

  function handleAddToCart() {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]')
    const found = cart.find(item => item.id === product.id)
    if (found) {
      found.qty += 1
    } else {
      cart.push({ ...product, qty: 1 })
    }
    localStorage.setItem('cart', JSON.stringify(cart))
    alert('Added to cart!')
  }

  if (loading) return <p>Loading...</p>
  if (!product) return <p>Product not found.</p>

  return (
    <section>
      <button className="btn" onClick={() => navigate(-1)}>
        &larr; Back
      </button>
      <div className="product-detail">
        <img src={product.image} alt={product.name} />
        <div>
          <h2>{product.name}</h2>
          <h4>{product.brand}</h4>
          <p>{product.description}</p>
          <p>
            <b>Category:</b> {product.category}
          </p>
          <p className="price">${product.price.toFixed(2)}</p>
          <button className="btn" onClick={handleAddToCart}>
            Add to Cart
          </button>
        </div>
      </div>
    </section>
  )
}