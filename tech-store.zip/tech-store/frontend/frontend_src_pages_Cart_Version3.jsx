import React, { useEffect, useState } from 'react'

export default function Cart() {
  const [cart, setCart] = useState([])

  useEffect(() => {
    setCart(JSON.parse(localStorage.getItem('cart') || '[]'))
  }, [])

  function removeFromCart(id) {
    const updated = cart.filter(item => item.id !== id)
    setCart(updated)
    localStorage.setItem('cart', JSON.stringify(updated))
  }

  function updateQty(id, qty) {
    const updated = cart.map(item =>
      item.id === id ? { ...item, qty: Math.max(1, qty) } : item
    )
    setCart(updated)
    localStorage.setItem('cart', JSON.stringify(updated))
  }

  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0)

  if (!cart.length)
    return (
      <section>
        <h2>Your Cart</h2>
        <p>Your cart is empty.</p>
      </section>
    )

  return (
    <section>
      <h2>Your Cart</h2>
      <table className="cart-table">
        <thead>
          <tr>
            <th>Product</th>
            <th>Qty</th>
            <th>Price</th>
            <th>Total</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {cart.map(item => (
            <tr key={item.id}>
              <td>{item.name}</td>
              <td>
                <input
                  type="number"
                  value={item.qty}
                  min="1"
                  onChange={e => updateQty(item.id, parseInt(e.target.value))}
                  style={{ width: 40 }}
                />
              </td>
              <td>${item.price.toFixed(2)}</td>
              <td>${(item.price * item.qty).toFixed(2)}</td>
              <td>
                <button className="btn" onClick={() => removeFromCart(item.id)}>
                  Remove
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <p>
        <b>Cart Total:</b> ${total.toFixed(2)}
      </p>
    </section>
  )
}