const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Serve product images statically
app.use('/images', express.static(path.join(__dirname, 'images')));

// Get all products
app.get('/api/products', (req, res) => {
  const products = require('./products.json');
  res.json(products);
});

// Get product by ID
app.get('/api/products/:id', (req, res) => {
  const products = require('./products.json');
  const product = products.find(p => p.id === parseInt(req.params.id));
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json(product);
});

// Basic root endpoint
app.get('/', (req, res) => {
  res.send('Tech Store API running');
});

app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});