# Tech Store – Simple E-Commerce Demo

A simple, original e-commerce site for laptops, smartphones, and more.  
**Built with Node.js + Express (backend) and React (Vite) (frontend).**

---

## Features

- Home, Products, Product Detail, Cart pages
- Responsive, clean UI
- Simple cart (stored in browser)
- Easy to add more products

---

## Local Setup Instructions

### 1. Clone or Download

Place all files in a folder, preserving the `backend/` and `frontend/` directories.

### 2. Backend Setup

```bash
cd backend
npm install
# Place your product images in backend/images/
npm start
# Server runs on http://localhost:5000
```

### 3. Frontend Setup

Open a new terminal in `frontend/`:

```bash
cd frontend
npm install
npm run dev
# App runs on http://localhost:5173 (Vite default)
```

### 4. Usage

- Browse to [http://localhost:5173](http://localhost:5173)
- Add products to your cart, view details, etc.
- To add more products, edit `backend/products.json` and restart the backend if needed.
- Add product images to `backend/images/` (filename must match `"image"` path in the product JSON).

---

## Customization

- **Add products:** Edit `backend/products.json`
- **Add images:** Place images in `backend/images/`
- **Styling:** Edit `frontend/src/index.css`

---

## License

For demo and educational use only.